// How do we know we need a loop here?
// We use loops in programming when we want the computer to do something repeatedly or for a certain number of times

// What's the starting point of the loop?
// is where the loopbegins in repetitive execution


// When should the loop stop?
// the loop stop with his condition 


// How will the loop know when to stop?
//stops on specified condition 


// What's incrementing for each iteration of the loop?
// the step

// What variables do we need?
